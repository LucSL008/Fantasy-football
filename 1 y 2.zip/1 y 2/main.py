from itertools import combinations, product
import pandas as pd


PRESUPUESTO = 100
CUPOS = {"POR": 1, "DEF": 4, "MED": 4, "DEL": 2}
jugadores = pd.DataFrame(
    [
        ("Ortega", "POR", 9, 5.8),
        ("Lunin", "POR", 6, 4.6),
        ("Remiro", "POR", 4, 3.9),
        ("Koundé", "DEF", 12, 6.4),
        ("Mingueza", "DEF", 7, 5.1),
        ("Vivian", "DEF", 5, 4.2),
        ("Huijsen", "DEF", 9, 5.4),
        ("Cucurella", "DEF", 11, 5.9),
        ("Lejeune", "DEF", 3, 3.1),
        ("Mosquera", "DEF", 6, 4.5),
        ("Pedri", "MED", 18, 8.1),
        ("Baena", "MED", 13, 6.9),
        ("Sučić", "MED", 8, 5.2),
        ("Barrios", "MED", 10, 5.9),
        ("Fermín", "MED", 11, 6.2),
        ("Gaya", "MED", 4, 3.3),
        ("Arambarri", "MED", 6, 4.4),
        ("Mbappé", "DEL", 24, 9.6),
        ("Budimir", "DEL", 9, 6.0),
        ("Oyarzabal", "DEL", 14, 7.2),
        ("Iglesias", "DEL", 7, 4.8),
    ],
    columns=["Jugador", "Puesto", "Precio", "Puntos"],
)


def Mostrar_equipo(titulo, equipo):
    print(f"{titulo}")
    if not equipo:
        print("No se pudo completar un once.")
        return

    tabla_equipo = pd.DataFrame(equipo)
    print(tabla_equipo[["Jugador", "Puesto", "Precio", "Puntos"]])
    print(f"Precio total: {tabla_equipo['Precio'].sum()} M")
    print(f"Puntos totales: {tabla_equipo['Puntos'].sum()} puntos")


def Voraz(criterio):
    tabla = jugadores.copy()
    if criterio == "puntos":
        tabla = tabla.sort_values("Puntos", ascending=False, kind="stable")
    else:
        tabla["Ratio"] = tabla["Puntos"] / tabla["Precio"]
        tabla = tabla.sort_values("Ratio", ascending=False, kind="stable")

    equipo = []
    cantidades = {puesto: 0 for puesto in CUPOS}
    precio_total = 0

    for _, jugador in tabla.iterrows():
        puesto = jugador["Puesto"]
        if cantidades[puesto] == CUPOS[puesto]:
            continue
        if precio_total + jugador["Precio"] > PRESUPUESTO:
            continue

        equipo.append(jugador.to_dict())
        cantidades[puesto] += 1
        precio_total += jugador["Precio"]

    equipo_completo = cantidades == CUPOS
    return equipo, equipo_completo


def fuerza_bruta():
    opciones_por_puesto = []
    for puesto, cupo in CUPOS.items():
        jugadores_del_puesto = jugadores[jugadores["Puesto"] == puesto].to_dict("records")
        opciones_por_puesto.append(list(combinations(jugadores_del_puesto, cupo)))

    mejor_equipo = []
    mejores_puntos = -1
    mejores_precio = 0
    equipos_comprobados = 0
    equipos_dentro_presupuesto = 0

    for combinacion_por_puesto in product(*opciones_por_puesto):
        equipos_comprobados += 1
        equipo = [
            jugador
            for jugadores_del_puesto in combinacion_por_puesto
            for jugador in jugadores_del_puesto
        ]
        precio = sum(jugador["Precio"] for jugador in equipo)
        puntos = sum(jugador["Puntos"] for jugador in equipo)

        if precio <= PRESUPUESTO:
            equipos_dentro_presupuesto += 1
            if puntos > mejores_puntos:
                mejor_equipo = equipo
                mejores_puntos = puntos
                mejores_precio = precio

    return (
        mejor_equipo,
        equipos_comprobados,
        equipos_dentro_presupuesto,
        mejores_precio,
        mejores_puntos,
    )


if __name__ == "__main__":
    print(f"Presupuesto: {PRESUPUESTO} M")
    print(f"Jugadores disponibles: {len(jugadores)}")

    equipo_puntos, completo_puntos = Voraz("puntos")
    Mostrar_equipo("Voraz: ordenar por puntos", equipo_puntos)
    print(f"Once completo: {'sí' if completo_puntos else 'no'}")

    equipo_ratio, completo_ratio = Voraz("ratio")
    Mostrar_equipo("Voraz: ordenar por puntos/precio", equipo_ratio)
    print(f"Once completo: {'sí' if completo_ratio else 'no'}")

    (
        equipo_optimo,
        equipos_comprobados,
        equipos_dentro_presupuesto,
        precio_optimo,
        puntos_optimos,
    ) = fuerza_bruta()

    Mostrar_equipo("Fuerza bruta: mejor equipo", equipo_optimo)
    print(f"Combinaciones que respetan los cupos: {equipos_comprobados}")
    print(f"Combinaciones que además respetan el presupuesto: {equipos_dentro_presupuesto}")
    print(f"Óptimo: {puntos_optimos} puntos por {precio_optimo} M")